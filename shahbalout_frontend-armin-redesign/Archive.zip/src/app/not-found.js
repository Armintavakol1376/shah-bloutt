import React from 'react';

const page = () => {
    return (
        <div className="m-20">
            <h1>404 - Page Not Found</h1>
        </div>
    );
};

export default page;
