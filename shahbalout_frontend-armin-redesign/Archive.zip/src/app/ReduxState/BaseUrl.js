export const BASEURL = process.env.BASEURL;
