export const CoffeeCat = [
    { persian: 'هنر و تکنیک قهوه', eng: 'The art and technique of coffee' },
    { persian: 'علم قهوه', eng: 'The science of coffee' },
    { persian: 'دانستنی های حیاتی قهوه', eng: 'Vital knowledge of coffee' },
];

// export const CoffeeQA = [
//     { persian: 'هنر و تکنیک قهوه', eng: 'The art and technique of coffee' },
//     { persian: 'علم قهوه', eng: 'The science of coffee' },
//     { persian: 'دانستنی های حیاتی قهوه', eng: 'Vital knowledge of coffee' },
// ];
