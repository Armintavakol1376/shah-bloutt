import React, { useState, useContext } from "react";
import { ThemeContextExp } from "@/app/ContextArea/ThemeContext";
import {
  Dropdown,
  DropdownTrigger,
  DropdownMenu,
  DropdownItem,
  Button,
} from "@nextui-org/react";
import PriceSlicer from "../Global/PriceSlicer";

function RangeSelectioner({ selection, indexId, setItemValue, setItemTitle, max, titleItems }) {
  const [
    darkMode,
  ] = useContext(ThemeContextExp);

  const [value, setValue] = useState(0);
  const [title, setTitle] = useState("انتخاب");
  const [price, setPrice] = useState(0);

  // این state برای کنترل اینکه کدوم منو باز باشه
  const [openDropdownId, setOpenDropdownId] = useState(null);

  const onValueChangeHandle = (event) => {
    setValue(event.target.value);
    setItemValue(event.target.value, indexId, price);
  };

  // کامپوننت SelectCard با id و وضعیت باز بودن بر اساس state بالا
  const SelectCard = ({ id }) => {
    const isOpen = openDropdownId === id;

    // فقط با کلیک روی دکمه باز و بسته میشه، کلیک بیرون تاثیری نداره
    const toggleDropdown = () => {
      if (isOpen) setOpenDropdownId(null);
      else setOpenDropdownId(id);
    };

    return (
      <div className="w-1/3" onClick={(e) => e.stopPropagation()}>
        <Dropdown
          isOpen={isOpen}
          onClose={() => {
            // این تابع در این حالت تاثیری نداره چون کلیک بیرون نباید بسته کنه منو رو
            // پس اینجا نمیذاریم openDropdownId تغییر کنه
          }}
          closeOnSelect={true}
          shouldBlockScroll={false}
          placement="bottom-right"
        >
          <DropdownTrigger>
            <Button
              variant="faded"
              className="font-modamBo"
              onClick={(e) => {
                e.stopPropagation();
                toggleDropdown();
              }}
            >
              {title}
            </Button>
          </DropdownTrigger>
          <DropdownMenu aria-label="Static Actions" className="p-4 text-right">
            <DropdownItem
              key="robusta-title"
              className="font-bold text-lg cursor-default"
              isDisabled
            >
              ربوستا
            </DropdownItem>
            {titleItems.products
              .filter(
                (item) =>
                  item.englishName !== "sample" &&
                  item.category === "winning" &&
                  item.package[0].priceIrr > 0 &&
                  item.package[0].countInStock !== 0 &&
                  item.persianName.includes("ربوستا")
              )
              .map((item, index) => (
                <DropdownItem
                  key={"robusta-" + index}
                  className="text-xl font-modamBo p-4"
                  onPress={() => {
                    const itemPrice = Number(item.package[0].priceIrr);
                    setPrice(itemPrice);
                    setValue(0);
                    setItemValue(0, indexId, itemPrice);
                    setItemTitle(item.persianName, indexId);
                    setTitle(item.persianName);
                    setOpenDropdownId(null); // منو بسته میشه بعد انتخاب
                  }}
                >
                  {item.persianName}
                  <span className="text-xs mx-1 font-modamEL">-</span>
                  <span className="text-xs mx-1">
                    {PriceSlicer(Number(item.package[0].priceIrr))}
                    <span className="text-xs mx-1 font-modamEL"> تومان هر ۲۵۰ گرم</span>
                  </span>
                </DropdownItem>
              ))}

            <DropdownItem
              key="arabica-title"
              className="font-bold text-lg cursor-default"
              isDisabled
            >
              عربیکا
            </DropdownItem>
            {titleItems.products
              .filter(
                (item) =>
                  item.englishName !== "sample" &&
                  item.category === "winning" &&
                  item.package[0].priceIrr > 0 &&
                  item.package[0].countInStock !== 0 &&
                  !item.persianName.includes("ربوستا")
              )
              .map((item, index) => (
                <DropdownItem
                  key={"arabica-" + index}
                  className="text-xl font-modamBo p-4"
                  onPress={() => {
                    const itemPrice = Number(item.package[0].priceIrr);
                    setPrice(itemPrice);
                    setValue(0);
                    setItemValue(0, indexId, itemPrice);
                    setItemTitle(item.persianName, indexId);
                    setTitle(item.persianName);
                    setOpenDropdownId(null); // منو بسته میشه بعد انتخاب
                  }}
                >
                  {item.persianName}
                  <span className="text-xs mx-1 font-modamEL">-</span>
                  <span className="text-xs mx-1">
                    {PriceSlicer(Number(item.package[0].priceIrr))}
                    <span className="text-xs mx-1 font-modamEL"> تومان هر ۲۵۰ گرم</span>
                  </span>
                </DropdownItem>
              ))}

            <DropdownItem
              className="text-xl font-modamBo p-4"
              color="danger"
              onPress={() => {
                setValue(0);
                setItemValue(0, indexId, 0);
                setItemTitle("انتخاب", indexId);
                setTitle("انتخاب");
                setOpenDropdownId(null);
              }}
            >
              پاک کردن
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      </div>
    );
  };

  return (
    <div
      className={
        darkMode
          ? "w-full bg-darkBgTwo flex flex-col rounded-xl p-4 md:p-10 pb-8 my-10"
          : "w-full bg-lightBgThree border-3 border-darkBgTwo rounded-xl flex flex-col p-4 md:p-10 pb-8 my-10"
      }
    >
      <div className="w-full flex flex-row justify-between items-center mb-16">
        <SelectCard id={indexId} />
        {/* در صورت وجود چند منو، با id متفاوت */}
      </div>

      <input
        disabled={title === "انتخاب"}
        id="steps-range"
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={onValueChangeHandle}
        step={5}
        className="w-full h-4 rounded appearance-none cursor-pointer range-xl  
[&::-webkit-slider-thumb]:h-12
[&::-webkit-slider-thumb]:w-5
[&::-webkit-slider-thumb]:appearance-none
[&::-webkit-slider-thumb]:shadow-[0px_0px_0_6px_#ad1037]
[&::-webkit-slider-thumb]:bg-lightBg
[&::-webkit-slider-thumb]:rounded
[&::-webkit-slider-thumb]:transition-all
[&::-webkit-slider-thumb]:duration-150
[&::-webkit-slider-thumb]:ease-in-out
"
      />
    </div>
  );
}

export default RangeSelectioner;
