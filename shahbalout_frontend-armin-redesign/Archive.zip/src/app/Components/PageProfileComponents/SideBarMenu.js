'use client';
import React, { useContext, useEffect, useState } from 'react';
import { ThemeContextExp } from '@/app/ContextArea/ThemeContext';

const SideBarMenu = ({ children }) => {
    const [
        darkMode,
        setDarkMode,
        persianLan,
        setPersianLan,
        modalMission,
        setModalMission,
        cartItems,
        setCartItems,
    ] = useContext(ThemeContextExp);

    const [isClient, setIsClient] = useState(false);

    useEffect(() => {
        setIsClient(true);
    }, []);

    return (
        <div
            className={
                darkMode
                    ? persianLan
                        ? 'w-full  overflow-y-auto  flex flex-col items-end relative border-2 border-lightBg border-opacity-10 my-2 z-10 md:mx-0 backdrop-blur rounded-xl p-6 bg-[rgba(200,200,200,0.15)] py-10 pb-auto'
                        : 'w-full  overflow-y-auto flex flex-col items-start relative border-2 border-lightBg border-opacity-10 my-2 z-10 md:mx-0 backdrop-blur rounded-xl p-6 bg-[rgba(200,200,200,0.15)] py-10 pb-auto'
                    : persianLan
                    ? 'w-full  overflow-y-auto flex flex-col items-end relative border-0 border-lightBg border-opacity-10 my-2 z-10 md:mx-0 backdrop-blur rounded-2xl p-6 bg-gradient-to-r from-[rgba(140,130,182,0.2)] to-lightBg shadow-lg py-10 pb-auto'
                    : 'w-full  overflow-y-auto flex flex-col items-start relative border-0 border-lightBg border-opacity-10 my-2 z-10 md:mx-0 backdrop-blur rounded-2xl p-6 bg-gradient-to-r from-[rgba(140,130,182,0.2)] to-lightBg shadow-lg py-10 pb-auto'
            }
        >
            {isClient && children}
        </div>
    );
};

export default SideBarMenu;
