export const SideBarMenuTilesArray = [
  { id: 0, persianTtl: "سفارش های خرید", englishTtl: "Orders" },
  // { id: 3, persianTtl: 'روتین سفارش قهوه', englishTtl: 'Coffe Lover Events' },
  { id: 1, persianTtl: "(افزودن آدرس) ویرایش پروفایل", englishTtl: "Profile Edit" },
  { id: 2, persianTtl: " پشتیبانــی", englishTtl: "Supports Ticket" },
  // { id: 4, persianTtl: 'دربــــــــــاره ما', englishTtl: 'About Us' },
  { id: 5, persianTtl: "خروج از حساب", englishTtl: "Logout" },
];

export const SideBarMenuTilesArrayByAdmin = [
  { id: 0, persianTtl: "سفارش های خرید", englishTtl: "Orders" },
  { id: 1, persianTtl: "کاربران", englishTtl: "Users" },
  //   { id: 2, persianTtl: " پشتیبانــی", englishTtl: "Supports Ticket" },
  { id: 3, persianTtl: "محصولات", englishTtl: "Products" },
  { id: 4, persianTtl: "(افزودن آدرس) ویرایش پروفایل", englishTtl: "Profile Edit" },
  { id: 5, persianTtl: "خروج از حساب", englishTtl: "Logout" },
];
