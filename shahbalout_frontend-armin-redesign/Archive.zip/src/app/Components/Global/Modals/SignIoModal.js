"use client";
import React, { useContext, useState, useEffect } from "react";
import Lottison from "../Lottison";
import coffeebuy from "../../../../../public/assets/lotties/coffeebuy.json";
import { ThemeContextExp } from "@/app/ContextArea/ThemeContext";

import { Button, Input, Tabs, Tab, Checkbox  } from "@nextui-org/react";

import {InputOtp} from "@nextui-org/input-otp";

import { CheckIcon } from "../../Icons/CheckIcon";
import SuccessLottieTick from "../SuccessLottieTick";
import CloseBulkIcon from "../../Icons/CloseBulkIcon";

import { useSelector, useDispatch } from "react-redux";
import {
  useLoginByPhoneMutation,
  useRegisterByPhoneMutation,
  useSentOtpByPhoneMutation,
  useRegisterByEmailMutation,
  useLoginByEmailMutation,
  useSentOtpByEmailMutation,
} from "@/app/ReduxState/Slices/userApiSlice";
import { setCredentials } from "@/app/ReduxState/Slices/authSlice";
import InputCustom from "../InputCustom";

const SignIoModal = ({ Default }) => {
  const [
    darkMode,
    setDarkMode,
    persianLan,
    setPersianLan,
    modalMission,
    setModalMission,
    cartItems,
    setCartItems,
  ] = useContext(ThemeContextExp);

  const p2e = s => s.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))

  const [switchMission, setSwitchMission] = useState(Default);
  const [otpWay, setOtpWay] = useState("Number");
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [otp, setOtp] = useState();
  const [seconds, setSeconds] = useState(60);
  const [problem, setProblem] = useState({ err: false, message: null });

  const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.auth);

  const [loginByPhone, { isLoading, isFetching, isError }] =
    useLoginByPhoneMutation();
  const [registerByPhone] = useRegisterByPhoneMutation();
  const [sentOtpByPhone] = useSentOtpByPhoneMutation();
  const [registerByEmail] = useRegisterByEmailMutation();
  const [loginByEmail] = useLoginByEmailMutation();
  const [sentOtpByEmail] = useSentOtpByEmailMutation();

  const otpSendHandle = async () => {
    setProblem({ err: false, message: null });
    otpWay == "NumberOtpSend"
      ? setOtpWay("NumberOtpProcess")
      : setOtpWay("EmailOtpProcess");
    try {
      const res =
        otpWay == "NumberOtpSend"
          ? await sentOtpByPhone({ otp: p2e(otp) }).unwrap()
          : await sentOtpByEmail({ otp: p2e(otp) }).unwrap();
      res.success && dispatch(setCredentials({ ...res }));
      res.success && otpWay == "NumberOtpProcess"
        ? setOtpWay("NumberOtpVerify")
        : setOtpWay("EmailOtpVerify");
    } catch (error) {
      otpWay == "NumberOtpProcess"
        ? setOtpWay("NumberOtpSend")
        : setOtpWay("EmailOtpSend");
      setProblem({ err: true, message: null });
    }
  };

  const registerHandle = async () => {
    setProblem({ err: false, message: null });
    try {
      const res =
        otpWay == "Number"
          ? await registerByPhone({ number: Number(p2e((phone))), name: name }).unwrap()
          : await registerByEmail({ email: email, name: name }).unwrap();

      res.success && otpWay == "Number"
        ? setOtpWay("NumberOtpSend")
        : setOtpWay("EmailOtpSend");
      const interval = setInterval(() => {
        setSeconds((seconds) => seconds - 1);
      }, 1000);
      return () => clearInterval(interval);
    } catch (error) {
      setProblem({ err: true, message: error.data.message });
      console.log("err:", error);
    }
  };

  const loginHandle = async () => {
    setProblem({ err: false, message: null });
    try {
      const res =
        otpWay == "Number"
          ? await loginByPhone({ number: Number(p2e((phone))) }).unwrap()
          : await loginByEmail({ email: email }).unwrap();
      res.success && otpWay == "Number"
        ? setOtpWay("NumberOtpSend")
        : setOtpWay("EmailOtpSend");
      const interval = setInterval(() => {
        setSeconds((seconds) => seconds - 1);
      }, 1000);
      return () => clearInterval(interval);
    } catch (error) {
      setProblem({ err: true, message: error.data.message });
      console.log("err:", error);
    }
  };

  return (
    <div
      className={
        darkMode
          ? "w-screen flex flex-col items-center md:w-96   mt-auto mb-0 rounded-t-3xl border-3 border-lightBg border-opacity-30 my-2 z-10 md:mx-0 backdrop-blur rounded-2xl p-4 bg-darkBg bg-opacity-80 "
          : "w-screen flex flex-col items-center md:w-96   mt-auto mb-0 rounded-t-3xl bg-lightBg px-6 z-50 border-0 border-lightBg border-opacity-10 my-2 md:mx-0 backdrop-blur rounded-2xl  "
      }
    >
      {/* Header Register or Login */}
      <div className="w-full -mt-4 flex justify-end z-0">
        <span
          className={
            darkMode
              ? "text-darkTxtOne font-modamBl text-xl mt-auto mb-6 "
              : "text-lightTxtOne font-modamBl text-xl mt-auto mb-6 drop-shadow-xl"
          }
        >
          {persianLan
            ? switchMission == "Login"
              ? "ورود"
              : "ثبت نام"
            : switchMission == "Login"
            ? "Sign In"
            : "Sign Up"}
        </span>




        {switchMission == "Login" ? (
          <img
            src="/assets/imgs/icon/fingerprint.png"
            className=" h-20 ml-2 object-contain bg-transparent rounded-xl drop-shadow-xl "
          />
        ) : (
          <img
            src="/assets/imgs/icon/lockImg.png"
            className="h-24 ml-2 object-contain bg-transparent rounded-xl drop-shadow-xl "
          />
        )}

        <Button
          isIconOnly
          color="light"
          onClick={() => setModalMission({ ...modalMission, appear: false })}
          className="w-10 h-10  mt-auto mb-4"
        >
          <CloseBulkIcon Size={48} Fill={darkMode ? "#ad1037" : "#292D32"} />
        </Button>
      </div>

      {/*Error*/}
      {problem.err && (
        <p className={"text-[#ad1037] text-center font-modamBo p-2"}>
          {persianLan
            ? problem.message != "user already exists"
              ? "مشکلی رخ داده است دوباره تلاش نماییید و واینترنت خود را چک نمایید لطفا"
              : "!این کاربر قبلا ثبت شده است"
            : problem.message}
        </p>
      )}

      {/* Email || Number Insert */}
      {(otpWay == "Number" || otpWay == "Email") && (
        <>

     { switchMission == "Login" &&   <p className={"text-[#ad1037] text-sm text-center font-modamR p-2 cursor-pointer"} onClick={()=>setSwitchMission("Register") }>
       اگر حساب کاربری ندارید ابتدا ثبت نام نمایید
       <p className={"text-[#ad1037] text-sm text-center font-modamBo p-2"} onClick={()=>setSwitchMission("Register") }>
       (ثبت نام)    
        </p> </p>}

        { switchMission == "Register" &&   <p className={"text-[#ad1037] text-sm text-center font-modamR p-2"} onClick={()=>setSwitchMission("Login") }>
        اگر حساب کاربری دارید لطفا وارد شوید
        <p className={"text-[#ad1037] text-sm text-center font-modamBo p-2 cursor-pointer"} onClick={()=>setSwitchMission("Register") }>
       (وارد شدن)    
        </p> </p>}



        <div className="flex flex-col items-start gap-2">
     
    </div>
          {/* <div className="flex flex-row w-full  items-center justify-around">
            <Checkbox
              isSelected={otpWay == "Email" ? true : false}
              color="success"
              className={
                persianLan ? "flex flex-row-reverse gap-1" : "flex flex-row"
              }
              onChange={() => setOtpWay("Email")}
            >
              <span
                className={
                  darkMode
                    ? "text-darkTxtOne font-modamR pt-1 text-xs"
                    : "text-lightTxtOne font-modamR text-xs"
                }
              >
                {persianLan ? "ارسال از طریق ایمیـــل" : "Send By Email"}
              </span>
            </Checkbox>
            <Checkbox
              isSelected={otpWay == "Number" ? true : false}
              color="success"
              className={
                persianLan ? "flex flex-row-reverse gap-1" : "flex flex-row"
              }
              onChange={() => setOtpWay("Number")}
            >
              <span
                className={
                  darkMode
                    ? "text-darkTxtOne font-modamR text-xs"
                    : "text-lightTxtOne font-modamR text-xs"
                }
              >
                {persianLan ? "ارسال از طریق موبایـــل" : "Send By Mobile"}
              </span>
            </Checkbox>
          </div> */}

          {switchMission == "Register" && (
            <>
              <p
                className={
                  darkMode
                    ? "w-full  text-center mt-8  text-darkTxtOne font-modamBl"
                    : "w-full  text-center mt-8  text-lightTxtOne font-modamBl"
                }
              >
                {persianLan
                  ? ":لطفا نام و نام خانوادگی خود را وارد نمایید"
                  : "Please insert your Name:"}
              </p>
              <InputCustom
                Value={name}
                onChangeFrom={(e) => {
                  return setName(e.target.value);
                }}
              />
            </>
          )}
          <p
            className={
              darkMode
                ? "w-full  text-center mt-8  text-darkTxtOne font-modamBl"
                : "w-full  text-center mt-8  text-lightTxtOne font-modamBl"
            }
          >
            {otpWay == "Number"
              ? persianLan
                ? ":لطفا شماره موبایل خود را وارد نمایید"
                : "Please insert your Phone number:"
              : persianLan
              ? ":لطفا ایمیل خود را وارد نمایید"
              : "Please insert your Email:"}
          </p>

          <InputCustom
          Value={otpWay == "Number" ? phone : email}
            onChangeFrom={(e) => {
              return otpWay == "Number"
                ? setPhone(e.target.value)
                : setEmail(e.target.value);
            }}
          />
          <Button
            onPress={switchMission == "Register" ? registerHandle : loginHandle}
            color="danger"
            className="w-full py-6 mb-2 mt-4 md:mt-16 font-modamBl hover:scale-102 text-lg"
            variant="shadow"
          >
            {persianLan ? "ارسال کد" : "Sent OTP"}
          </Button>
        </>
      )}

      {/*OTP lIVE DURATION */}
      {(otpWay == "NumberOtpSend" || otpWay == "EmailOtpSend") && (
        <>
          <div className="flex flex-row w-full  items-center justify-around">
            <div
              className={
                persianLan
                  ? "flex flex-row items-center justify-center"
                  : "flex flex-row-reverse items-center justify-center"
              }
            >
              <span
                className={
                  darkMode
                    ? "text-darkTxtOne font-modamR text-xs"
                    : "text-lightTxtOne font-modamR text-xs"
                }
              >
                {persianLan
                  ? "ثانیه دیگر دوباره می توانید ارسال نمایید"
                  : "Seconds later send again"}
              </span>

              <span
                className={
                  darkMode
                    ? "text-darkTxtOne font-modamEng  px-2"
                    : "text-lightTxtOne font-modamEng  px-2"
                }
              >
                {" "}
                {seconds}
              </span>

              <img
                src="/assets/imgs/icon/timer.png"
                className="w-20 object-contain bg-transparent rounded-xl drop-shadow-xl "
              />
            </div>
          </div>


          <InputOtp length={6} value={otp} onValueChange={setOtp} className="font-modamBl  p-6 rounded-lg border-dashed" size='lg' variant= {darkMode? 'flat': "bordered"} />
  

          {/* <InputCustom
            //Type="number"
            Id="otp"
            Name="otp"
            Value={otp}
            onChangeFrom={(e) => {
              return setOtp(e.target.value);
            }}
          /> */}


          <Button
            onPress={otpSendHandle}
            color="success"
            className="w-full py-8 mb-40 mt-6 md:mt-16 font-modamBl hover:scale-102 text-lg"
            variant="shadow"
            isLoading={
              otpWay == "NumberOtpProcess" || otpWay == "EmailOtpProcess"
                ? true
                : false
            }
            spinner={
              <svg
                className="animate-spin h-5 w-5 text-current"
                fill="none"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  fill="currentColor"
                />
              </svg>
            }
          >
            {persianLan ? "ثبت" : "Sent OTP"}
          </Button>
        </>
      )}
      {/* Button Switch Register or Login */}
      {(seconds == 60 || seconds < 3) && (
        <Button
          color="danger"
          variant="flat"
          className="w-full py-6 mt-2 mb-40 text-lg"
          onPress={() =>
            switchMission == "Login"
              ? setSwitchMission("Register")
              : setSwitchMission("Login")
          }
        >
          {switchMission == "Login"
            ? persianLan
              ? "ثبت نام"
              : "Register"
            : persianLan
            ? "ورود به حساب"
            : "Login"}
        </Button>
      )}

      {/*Success Operation*/}
      {(otpWay == "NumberOtpVerify" || otpWay == "EmailOtpVerify") && (
        <>
          <SuccessLottieTick
            PersianTtl={"خوش آمدید"}
            EngTtl={"Welcome Dear."}
            OnClickFrom={() =>
              setModalMission({ ...modalMission, appear: false })
            }
          />
        </>
      )}
    </div>
  );
};

export default SignIoModal;
