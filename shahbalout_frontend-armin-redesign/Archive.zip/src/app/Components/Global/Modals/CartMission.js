'use client';
import React from 'react';

const CartMission = () => {
    return <div>CartMission</div>;
};

export default CartMission;
